package com.vishu.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.vishu.Dao.signup1dao;
import com.vishu.model.signup1model;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextPane;
import java.awt.SystemColor;
import java.util.Random;
import java.awt.TextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class signup1 extends JFrame {

	private JPanel contentPane;
	private JTextField tname;
	private JTextField tfname;
	private JTextField tadress;
	private JTextField tcity;
	private JTextField tstate;
	private JTextField tpin;

	  public  JLabel form;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					signup1 frame = new signup1();
					frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public signup1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 549, 498);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		setLocation(400,140);
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("SignUp");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setBounds(179, 14, 78, 20);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_1.setBounds(88, 97, 69, 14);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Fathers Name");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_2.setBounds(88, 143, 78, 14);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Adress");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_3.setBounds(88, 188, 69, 14);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("City");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_4.setBounds(88, 225, 69, 14);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("State");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_5.setBounds(88, 264, 69, 14);
		panel.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Pincode");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_6.setBounds(88, 302, 69, 14);
		panel.add(lblNewLabel_6);
		
		tname = new JTextField();
		tname.setBounds(227, 94, 131, 20);
		panel.add(tname);
		tname.setColumns(10);
		
		tfname = new JTextField();
		tfname.setBounds(227, 140, 131, 20);
		panel.add(tfname);
		tfname.setColumns(10);
		
		tadress = new JTextField();
		tadress.setBounds(227, 185, 131, 20);
		panel.add(tadress);
		tadress.setColumns(10);
		
		tcity = new JTextField();
		tcity.setBounds(227, 222, 131, 20);
		panel.add(tcity);
		tcity.setColumns(10);
		
		tstate = new JTextField();
		tstate.setBounds(227, 261, 131, 20);
		panel.add(tstate);
		tstate.setColumns(10);
		
		tpin = new JTextField();
		tpin.setBounds(227, 299, 131, 20);
		panel.add(tpin);
		tpin.setColumns(10);
		
		JButton btnNewButton = new JButton("Next");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		
				if (valid()) {
				
					 signup1model ss = new  signup1model();
					
					ss.setName(name);
					ss.setFname(fname); 
					ss.setAdress(adress);
					ss.setCity(city); 
					ss.setState(state); 
					ss.setPin(pin); 


				
					signup1dao signDao = signup1dao.getsignupDao();
					int i = signDao.insert(ss);
					if (i > 0) {
						JOptionPane.showMessageDialog(signup1.this, "Successfully Register");
						
						signup2 ja=new signup2();
						ja.setVisible(true);
						dispose();
						
					} else {
						JOptionPane.showMessageDialog(signup1.this, "Registered Failed");
					}

				}
			}
	
			
			
			
			
		});
		
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton.setBounds(154, 393, 89, 23);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Exit");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			dispose();
			}
		});
		
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton_1.setBounds(269, 393, 89, 23);
		panel.add(btnNewButton_1);
		
		
		JLabel lblNewLabel_8 = new JLabel("Form Number");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_8.setBounds(344, 14, 89, 23);
		panel.add(lblNewLabel_8);
		
		 form = new JLabel("");
		form.setBounds(444, 14, 69, 19);
		panel.add(form);
		
	
		
		Random rand=new Random();

     
        int randomPIN = (int)(Math.random()*9000)+1000;
String val=String.valueOf(randomPIN);
	
form.setText(val);

	
	
	}
	
	
	
	private String name,fname,adress,city,state;
	String pin;

	private boolean valid() {
		name = tname.getText();
		fname = tfname.getText();
		adress = tadress.getText();
		city = tcity.getText();
		state = tstate.getText();
		pin = tpin.getText().toString();

		if (name.isEmpty()) {
			
			tname.requestFocus();
			return false;
		} else if (fname.isEmpty()) {
		
			tfname.requestFocus();
			return false;
		} else if (adress.isEmpty()) {
			
			tadress.requestFocus();
			return false;
	
		} else if (city.isEmpty()) {
			
			tcity.requestFocus();
			return false;
} else if (state.isEmpty()) {
			
			tstate.requestFocus();
			return false;
} else if (pin.isEmpty()) {
	
	tpin.requestFocus();
	return false;
		}
else {
	return true;
	}
}
}