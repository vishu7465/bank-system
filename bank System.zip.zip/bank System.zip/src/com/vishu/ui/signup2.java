package com.vishu.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.vishu.Dao.signup1dao;
import com.vishu.model.signup1model;
import com.vishu.model.signup2model;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JCheckBox;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class signup2 extends JFrame {

	private JPanel contentPane;
	private JTextField tadhar;
	private JTextField tpan;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	//public static void main(String[] args) {
		//EventQueue.invokeLater(new Runnable() {
			/*public void run() {
				try {
					signup2 frame = new signup2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});*/
	

	/**
	 * Create the frame.
	 */
	public signup2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 542, 496);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		setLocation(400,140);
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Personal Details");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(169, 22, 128, 25);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Form Number :");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_1.setBounds(321, 27, 82, 14);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Adhar Number");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_2.setBounds(108, 90, 88, 14);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Pan Number");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_3.setBounds(108, 135, 88, 14);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Set Pin");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_4.setBounds(108, 174, 88, 14);
		panel.add(lblNewLabel_4);
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("Please Accept Terms and Conditions.");
		chckbxNewCheckBox.setFont(new Font("Tahoma", Font.BOLD, 11));
		chckbxNewCheckBox.setBounds(140, 230, 231, 23);
		panel.add(chckbxNewCheckBox);
		
		tadhar = new JTextField();
		tadhar.setBounds(272, 87, 113, 25);
		panel.add(tadhar);
		tadhar.setColumns(10);
		
		tpan = new JTextField();
		tpan.setBounds(272, 132, 113, 28);
		panel.add(tpan);
		tpan.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(413, 25, 64, 20);
		panel.add(textField_3);
		textField_3.setColumns(10);
		
		JButton btnNewButton = new JButton("Sign Up");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		
				if (valid()) {
				
					 signup2model ss = new  signup2model();
					
					ss.setAdhar(adhar);
					ss.setPan(pan);
					ss.setPin(pin);


					// send this model class object to database layer
					signup1dao signDao = signup1dao.getsignupDao();
					int i = signDao.insert2(ss);
					if (i > 0) {
						JOptionPane.showMessageDialog(signup2.this, "Successfully Register");
						
					} else {
						JOptionPane.showMessageDialog(signup2.this, "Registered Failed");
					}

				}
			
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton.setBounds(208, 283, 89, 23);
		panel.add(btnNewButton);
		
		tpin = new JPasswordField();
		tpin.setBounds(272, 174, 113, 28);
		panel.add(tpin);
	}
	

	private String adhar,pan;
	String pin,chckbxNewCheckBox;
	private JPasswordField tpin;

	private boolean valid() {
		adhar = tadhar.getText();
		pan = tpan.getText();
		
		pin=String.valueOf(tpin.getPassword());
		if (adhar.isEmpty()) {
			
			tadhar.requestFocus();
			return false;
		} else if (pan.isEmpty()) {
		
			tpan.requestFocus();
			return false;
		} else if (pin.isEmpty()) {
			
			tpin.requestFocus();
			return false;
	
		
	

	}

		else {
	return true;
	}
	}
}

