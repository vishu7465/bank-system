package com.vishu.Dao;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;


public class Dao {
    public static Statement s;
	private static Connection con;
	 public static Connection getConnection() 
	 {
	try {
	
		Class.forName("com.mysql.cj.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/banksystem", "root", "root");
		  s =con.createStatement(); 
			
	}catch(Exception e) {
		
	
	}
	return con;
	
}
}
