package com.vishu.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.vishu.model.*;

public class signup1dao {
	
	private static signup1dao signupDao = new signup1dao();

	private signup1dao() {

	}

	public static signup1dao getsignupDao() {
		return signupDao;
	}
	public int insert(signup1model signup1model) {
		int i = 0;
		
		try (Connection con = Dao.getConnection();) {
			PreparedStatement ps = con.prepareStatement("insert into signup1 values(?,?,?,?,?,?)");
			ps.setString(1, signup1model.getName());	
			ps.setString(2, signup1model.getFname());	
			ps.setString(3, signup1model.getAdress());
			ps.setString(4, signup1model.getCity());	
			ps.setString(5, signup1model.getState());	
			ps.setString(6, signup1model.getPin());	
			i = ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
		return i;
	}
	public int insert2(signup2model signup2model) {
		int i = 0;
		
		try (Connection con = Dao.getConnection();) {
			PreparedStatement ps = con.prepareStatement("insert into signup2 values(?,?,?)");
			ps.setString(1, signup2model.getAdhar());	
			ps.setString(2, signup2model.getPan());	
			ps.setString(3, signup2model.getPin());
			i = ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
		return i;
	}

	public int insert3(signup3model signup3model) {
		
		int i=0;
		try(Connection con=Dao.getConnection();){
			PreparedStatement ps=con.prepareStatement("insert into signup3 values(?,?)");
			ps.setString(1, signup3model.getCard());
			ps.setInt(2, signup3model.getPin());
			
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		
	
	
	return i;

}
	public int log(bankmodel bankmodel) throws SQLException {
		
		int i=0;
		try(Connection con=Dao.getConnection();){
			PreparedStatement ps=con.prepareStatement("select * from signup3 where(?,?)");
			ResultSet rs=ps.executeQuery();
		
		
	}
	return i;
}
}