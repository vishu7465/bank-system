package com.vishu.model;

public class signinmodel {

	private int atmnumber;
	private int pin;
	public int getAtmnumber() {
		return atmnumber;
	}
	public void setAtmnumber(int atmnumber) {
		this.atmnumber = atmnumber;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	
	
}
