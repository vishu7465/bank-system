package com.vishu.model;

public class signup2model {

	private String adhar;
	private String pan;
	private String pin;
	public String getAdhar() {
		return adhar;
	}
	public void setAdhar(String adhar) {
		this.adhar = adhar;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin2) {
		this.pin = pin2;
	}
	
}
